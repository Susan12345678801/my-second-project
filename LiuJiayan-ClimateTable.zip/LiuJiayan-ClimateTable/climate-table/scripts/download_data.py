"""Download NBS table images and verify their content and checksums."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import time
from urllib.request import Request, urlopen
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.constants import ROOT, YEARS

def get_bytes(url):
    error=None
    for attempt in range(3):
        try:
            with urlopen(Request(url,headers={"User-Agent":"ClimateTableChina/1.0"}),timeout=35) as response:
                body=response.read()
                if response.status!=200:raise ValueError(f"HTTP {response.status}")
                return body,response.headers.get_content_type()
        except Exception as exc:
            error=exc
            if attempt<2:time.sleep(1+attempt)
    raise RuntimeError(f"Could not download {url}: {error}") from error

def discover_year(year):
    book=year+1;base=f"https://www.stats.gov.cn/sj/ndsj/{book}/"
    body,_=get_bytes(base+"left.htm")
    text=body.decode("gb18030")
    links=re.findall(r"<a href=['\"]([^'\"]+)['\"]>(.*?)</a>",text,re.I)
    rows=[]
    for kind,title in [("food","分地区居民家庭人均主要食品消费量"),
                       ("temperature","主要城市平均气温"),("precipitation","主要城市降水量")]:
        matches=[(href,t) for href,t in links if title in t]
        if len(matches)!=1:raise ValueError(f"Unexpected index matches: {year}, {kind}")
        href,label=matches[0];name=href.rsplit("/",1)[-1]
        name=name.replace("CH","EN") if "CH" in name else "E"+name[1:]
        rows.append(dict(year=year,yearbook=book,kind=kind,title=label,
                         source_url=base+"html/"+name,local_path=f"data/raw/{year}_{kind}.jpg"))
    return rows

def download_sources(refresh=False,discover=False,workers=4):
    manifest=ROOT/"data/sources.json"
    if discover or not manifest.exists():
        with ThreadPoolExecutor(workers) as pool:
            records=[r for rows in pool.map(discover_year,YEARS) for r in rows]
    else:records=json.loads(manifest.read_text())
    map_manifest=ROOT/"data/map_source.json"
    map_record=json.loads(map_manifest.read_text()) if map_manifest.exists() else dict(
        source_url="https://geo.datav.aliyun.com/areas_v3/bound/100000_full.json",
        local_path="data/raw/china_provinces.geojson",kind="map")
    def fetch(record):
        record=dict(record);path=ROOT/record["local_path"];status="verified cache"
        if refresh or not path.exists():
            body,content_type=get_bytes(record["source_url"])
            digest=hashlib.sha256(body).hexdigest()
            if record.get("sha256") and digest!=record["sha256"]:
                raise ValueError(f"Upstream file changed; review needed: {path.name}")
            if record["kind"]!="map" and not body.startswith(b"\xff\xd8"):
                raise ValueError(f"Expected a JPEG image: {path.name}")
            if record["kind"]=="map" and json.loads(body).get("type")!="FeatureCollection":
                raise ValueError("Invalid geographic file")
            path.parent.mkdir(parents=True,exist_ok=True)
            temporary=path.with_suffix(path.suffix+".part");temporary.write_bytes(body);temporary.replace(path)
            record.update(sha256=digest,content_type=content_type,bytes=len(body),status_code=200,
                          checked_at_utc=datetime.now(timezone.utc).isoformat())
            status="HTTP 200 download"
        if hashlib.sha256(path.read_bytes()).hexdigest()!=record["sha256"]:
            raise ValueError(f"Checksum mismatch: {path.name}")
        return record,dict(file=path.name,status=status,bytes=path.stat().st_size,source_url=record["source_url"])
    with ThreadPoolExecutor(workers) as pool:results=list(pool.map(fetch,records+[map_record]))
    manifest.parent.mkdir(exist_ok=True);manifest.write_text(json.dumps([r for r,_ in results[:-1]],indent=2,ensure_ascii=False))
    map_manifest.write_text(json.dumps(results[-1][0],indent=2))
    import pandas as pd
    log=pd.DataFrame([r for _,r in results]);(ROOT/"outputs").mkdir(exist_ok=True)
    log.to_csv(ROOT/"outputs/download_log.csv",index=False)
    return log

if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--refresh",action="store_true")
    parser.add_argument("--discover",action="store_true");args=parser.parse_args()
    print(download_sources(refresh=args.refresh,discover=args.discover).to_string(index=False))
