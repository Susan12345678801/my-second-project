# Weather and the Household Table in China

The project studies household food composition in 31 Chinese provinces during 2015–2023 and its association with capital-area summer warmth and annual rainfall departures. The data contain 279 matched province-year observations.


## Data interpretation

The NBS food tables report annual kilograms per person. Five groups combine eight original columns without adding nested cereal or meat subcategories. The denominator contains selected recorded food mass. Grain uses unprocessed weight, and foods differ in water content. The shares do not measure calories, complete dietary intake, or nutritional adequacy.

The English fruit heading changes from dried and fresh fruit to fresh fruit in 2022. The source tables do not explain whether this wording change reflects coverage or terminology. The vegetables-only sensitivity comparison excludes fruit and recalculates all five shares.

Each province uses one capital-area weather observation. Summer means weight June, July, and August by month length. Departures use each capital's 2015–2023 average, which is a study-period reference. Monthly averages do not identify heatwave days or individual storm events. The regressions and year comparisons describe associations.

All 27 NBS image URLs and the geographic URL returned HTTP 200 when the supplied snapshot was downloaded. `data/sources.json` and `data/map_source.json` retain their exact URLs, check dates, content types, sizes, and SHA-256 values. The image-reading audit records 3,804 numeric cells. The corrections file identifies the original year, table, column, and row of 183 readings checked against source images.

Tesseract is optional for the ordinary analysis. `python scripts/extract_tables.py` re-creates the digitization using two image scales, isolated-cell rechecks, and the supplied source-addressed corrections. New unresolved readings stop the export and require image review. Checked snapshots remain protected by checksums.
