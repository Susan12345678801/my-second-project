"""Tests for fixed effects, compositions, and leakage across years."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from src.data import validate_and_prepare
from src.constants import SHARES
from src.analysis import nuisance_matrix,residualize,panel_associations,bh_adjust,prediction_features,evaluate_predictions

class AnalysisChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.panel,_=validate_and_prepare()

    def test_fixed_effects_recover_known_coefficients(self):
        panel=self.panel;z=nuisance_matrix(panel)
        x=panel[["temp_anomaly_c","rain_10pct","rain_abs_10pct"]].to_numpy();beta=np.array([.25,-.03,.08])
        outcome=z@np.sin(np.arange(z.shape[1]))+x@beta
        recovered=np.linalg.lstsq(residualize(x,z),residualize(outcome,z),rcond=None)[0]
        np.testing.assert_allclose(recovered,beta,atol=1e-10)

    def test_composition_coefficients_sum_to_zero(self):
        result=panel_associations(self.panel)
        np.testing.assert_allclose(result.groupby("feature").beta.sum(),0,atol=1e-10)

    def test_multiple_comparison_adjustment(self):
        np.testing.assert_allclose(bh_adjust([.01,.04,.03,.2]),[.04,.053333333333,.053333333333,.2])

    def test_weather_reference_uses_training_observations(self):
        train=self.panel[self.panel.year<=2020];test=self.panel[self.panel.year.eq(2023)]
        features=prediction_features(test,train);expected=test.precip_mm/test.province.map(train.groupby("province").precip_mm.mean())-1
        np.testing.assert_allclose(features.rain_relative,expected)

    def test_final_year_targets_do_not_affect_predictions(self):
        altered=self.panel.copy();altered.loc[altered.year.eq(2023),SHARES]=[20,20,20,20,20]
        with tempfile.TemporaryDirectory() as folder,patch("src.analysis.ROOT",Path(folder)):
            _,_,original,summary=evaluate_predictions(self.panel)
            _,_,changed,changed_summary=evaluate_predictions(altered)
        np.testing.assert_allclose(original.predicted,changed.predicted,atol=1e-12)
        self.assertEqual(summary["tuned_alphas"],changed_summary["tuned_alphas"])
        np.testing.assert_allclose(original.groupby(["model","year","province"]).predicted.sum(),100,atol=1e-10)

if __name__=="__main__":unittest.main()
