"""Research figures for the food and weather comparisons."""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize, TwoSlopeNorm
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Polygon
from .constants import ROOT, GROUPS, SHARES, COLORS
plt.rcParams.update({"font.size":12,"axes.titlesize":13,"axes.labelsize":12,
 "axes.spines.top":False,"axes.spines.right":False,"savefig.dpi":180,"font.family":"DejaVu Sans"})

def save(fig,name):
    path=ROOT/"outputs/figures";path.mkdir(parents=True,exist_ok=True)
    for extension in ("png","pdf"):fig.savefig(path/f"{name}.{extension}",bbox_inches="tight",facecolor="white")
    plt.close(fig);return path/f"{name}.png"

def map_figure(panel,year=2023):
    features=json.loads((ROOT/"data/raw/china_provinces.geojson").read_text())["features"]
    snapshot=panel[panel.year.eq(year)].set_index("adcode")
    fig,axes=plt.subplots(1,3,figsize=(12,3.9),layout="constrained")
    specs=[("aquatic_share","Aquatic share (%)","YlGnBu",Normalize(0,10)),
           ("temp_anomaly_c","Summer departure (C)","RdBu_r",TwoSlopeNorm(0,-2,2)),
           ("rain_anomaly_pct","Rainfall departure (%)","BrBG",TwoSlopeNorm(0,-70,70))]
    for ax,(column,title,cmap,norm) in zip(axes,specs):
        palette=plt.get_cmap(cmap)
        for feature in features:
            geometry=feature["geometry"];code=feature["properties"]["adcode"]
            color=palette(norm(snapshot.loc[code,column])) if code in snapshot.index else "#ececec"
            polygons=[geometry["coordinates"]] if geometry["type"]=="Polygon" else geometry["coordinates"] if geometry["type"]=="MultiPolygon" else []
            for polygon in polygons:ax.add_patch(Polygon(polygon[0],closed=True,facecolor=color,edgecolor="white",linewidth=.35))
        ax.set(xlim=(73,136),ylim=(17,54),title=title);ax.title.set_fontsize(14)
        ax.set_aspect(1.23);ax.axis("off")
        bar=fig.colorbar(ScalarMappable(norm=norm,cmap=cmap),ax=ax,orientation="horizontal",shrink=.85,pad=.03)
        bar.ax.tick_params(labelsize=12)
    fig.suptitle(f"Household food and capital-area weather, {year}",fontsize=15)
    return save(fig,"climate_table_map")

def profile_figure(profiles,scores,centers):
    ordered=profiles.sort_values(["cluster","grain_share"]);data=ordered[SHARES].to_numpy()
    fig=plt.figure(figsize=(8.5,6.4),layout="constrained")
    grid=fig.add_gridspec(2,2,width_ratios=[1.75,1],height_ratios=[1.8,1])
    ax=fig.add_subplot(grid[:,0]);image=ax.imshow(data,cmap="YlGnBu",aspect="auto",vmin=0,vmax=65)
    ax.set_xticks(range(5),["Grain","Meat +\npoultry","Vegetables\n+ fruit","Eggs +\ndairy","Aquatic"],fontsize=10)
    ax.set_yticks(range(len(ordered)),ordered.index,fontsize=10)
    ax.set_title("Mean food shares, 2015-2023",fontsize=12)
    for i in range(len(data)):
        for j in range(5):ax.text(j,i,f"{data[i,j]:.1f}",ha="center",va="center",fontsize=9,color="white" if data[i,j]>43 else "#213447")
    for change in np.flatnonzero(np.diff(ordered.cluster.to_numpy())):ax.axhline(change+.5,color="#394454",lw=1.3)
    bar=fig.colorbar(image,ax=ax,orientation="horizontal",shrink=.85,pad=.05);bar.set_label("Share of selected food mass (%)",fontsize=10);bar.ax.tick_params(labelsize=9)
    ax=fig.add_subplot(grid[0,1]);left=np.zeros(len(centers))
    for j,(name,color) in enumerate(zip(GROUPS,COLORS)):
        vals=centers[SHARES[j]].to_numpy();ax.barh(range(len(centers)),vals,left=left,color=color,label=name);left+=vals
    ax.set_yticks(range(len(centers)),[f"{i}: n={int(r.provinces)}" for i,r in centers.iterrows()],fontsize=10)
    ax.set(xlim=(0,100),xlabel="Composition (%)",title="Profile centers");ax.title.set_fontsize(12)
    ax.legend(loc="upper center",bbox_to_anchor=(.5,-.18),frameon=False,fontsize=9)
    ax=fig.add_subplot(grid[1,1]);ax.plot(scores.k,scores.silhouette,"o-",color="#33485b")
    best=scores.loc[scores.silhouette.idxmax()];ax.scatter([best.k],[best.silhouette],s=60,color="#c96763",zorder=3)
    ax.set(xticks=scores.k,xlabel="Profile count",ylabel="Silhouette",title="Count comparison");ax.title.set_fontsize(12);ax.tick_params(labelsize=10)
    return save(fig,"province_profiles")

def trend_figure(panel):
    means=panel.groupby("year")[SHARES+["temp_anomaly_c","rain_anomaly_pct"]].mean()
    fig,axes=plt.subplots(1,2,figsize=(11,3.8),layout="constrained")
    for column,label,color in zip(SHARES,GROUPS,COLORS):axes[0].plot(means.index,means[column],"o-",label=label,color=color,lw=1.8,ms=4)
    axes[0].set(xlabel="Year",ylabel="Mean share (%)",title="Provincial food composition")
    axes[0].legend(fontsize=10,frameon=False,loc="center left",bbox_to_anchor=(1,.5))
    axes[1].bar(means.index,means.temp_anomaly_c,color="#c96763",alpha=.8)
    axes[1].set(xlabel="Year",ylabel="Summer departure (C)",title="Capital-area weather departures")
    axes[1].axhline(0,color="gray",lw=.8);twin=axes[1].twinx()
    twin.plot(means.index,means.rain_anomaly_pct,"o-",color="#477d87",lw=1.7,ms=4)
    twin.set_ylabel("Rainfall departure (%)",color="#477d87");axes[1].yaxis.label.set_color("#c96763")
    for ax in axes:ax.set_xticks(means.index[::2]);ax.grid(axis="y",alpha=.15)
    return save(fig,"food_weather_trends")

def dot_panels(table,value,panels,name,titles,xlabel):
    fig,axes=plt.subplots(1,3,figsize=(11.5,3.5),layout="constrained",sharey=True)
    for ax,(column,panel),title in zip(axes,panels,titles):
        part=table[table[column].eq(panel)].set_index("group").loc[GROUPS]
        for j,color in enumerate(COLORS):
            r=part.iloc[j];ax.plot([r.ci_low,r.ci_high],[j,j],color=color,lw=1.8);ax.scatter([r[value]],[j],color=color,s=35,zorder=3)
        ax.axvline(0,color="#777777",ls="--",lw=.8);ax.set_title(title);ax.set_xlabel(xlabel)
        ax.set_yticks(range(5),GROUPS,fontsize=12);ax.grid(axis="x",alpha=.15)
    axes[0].invert_yaxis();return save(fig,name)

def contrast_figure(frame):
    return dot_panels(frame,"difference_pp",[("comparison",s) for s in ["Warmer summers","Drier years","Wetter years"]],
                      "weather_year_contrasts",["Warmer summers","Drier years","Wetter years"],"Adjusted contrast (pp)")

def association_figure(frame):
    return dot_panels(frame,"beta",[("feature",s) for s in ["temp_anomaly_c","rain_10pct","rain_abs_10pct"]],
                      "panel_associations",["Summer: +1 C","Signed rain: +10 pp","Absolute rain: +10 pp"],"Food-share coefficient (pp)")

def sensitivity_figure(frame):
    fig,ax=plt.subplots(figsize=(9.2,4.1),layout="constrained")
    for i,(name,color) in enumerate(zip(frame.specification.unique(),["#2e465b","#c96763","#66a381","#9a86b4"])):
        part=frame[frame.specification.eq(name)].set_index("group").loc[GROUPS];y=np.arange(5)+(i-1.5)*.14
        ax.errorbar(part.beta,y,xerr=[part.beta-part.ci_low,part.ci_high-part.beta],fmt="o",ms=4,color=color,elinewidth=.9,label=name)
    ax.axvline(0,color="gray",ls="--",lw=.8)
    ax.set(yticks=range(5),yticklabels=GROUPS,xlabel="Food-share change per +1 C (pp)",title="Temperature estimates across specifications")
    ax.invert_yaxis();ax.legend(frameon=False,ncol=2,fontsize=10,loc="lower right");ax.grid(axis="x",alpha=.15)
    return save(fig,"association_sensitivity")

def prediction_figure(metrics):
    fig,ax=plt.subplots(figsize=(10.3,3.8),layout="constrained");x=np.arange(5)
    for i,(name,color) in enumerate(zip(["Previous year","Province + trend","Province + trend + weather"],["#a4acb4","#526f89","#cc806a"])):
        vals=metrics[metrics.model.eq(name)].set_index("group").loc[GROUPS].mae_pp
        ax.bar(x+(i-1)*.23,vals,width=.22,color=color,label=name)
    ax.set_xticks(x,["Grain","Meat and\npoultry","Vegetables\nand fruit","Eggs and\ndairy","Aquatic\nproducts"])
    ax.set(ylabel="Mean absolute error (pp)",title="Year-held-out food-share prediction, 2022-2023")
    ax.legend(frameon=False,fontsize=11,loc="upper right");ax.grid(axis="y",alpha=.15)
    return save(fig,"prediction_errors")
