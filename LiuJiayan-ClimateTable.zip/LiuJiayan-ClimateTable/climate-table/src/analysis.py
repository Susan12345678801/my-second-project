"""Provincial profiles, within-province associations, and temporal prediction."""
import json
import numpy as np
import pandas as pd
from scipy.stats import t
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import Ridge
from sklearn.metrics import silhouette_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from .constants import ROOT, GROUPS, SHARES
WEATHER_FEATURES=["temp_anomaly_c","rain_10pct","rain_abs_10pct"]

def write_table(frame,name):
    (ROOT/"outputs/tables").mkdir(parents=True,exist_ok=True)
    frame.to_csv(ROOT/"outputs/tables"/f"{name}.csv",index=False)
    return frame

def portraits(panel):
    profiles=panel.groupby("province")[SHARES].mean().sort_index()
    z=StandardScaler().fit_transform(profiles);scores=[];models={}
    for k in range(2,6):
        model=KMeans(n_clusters=k,n_init=30,random_state=42).fit(z);models[k]=model
        scores.append(dict(k=k,silhouette=silhouette_score(z,model.labels_)))
    scores=pd.DataFrame(scores);k=int(scores.loc[scores.silhouette.idxmax(),"k"]);labels=models[k].labels_
    order=pd.Series(profiles.grain_share.to_numpy()).groupby(labels).mean().sort_values().index
    renumber={old:new+1 for new,old in enumerate(order)}
    profiles["cluster"]=[renumber[x] for x in labels]
    centers=profiles.groupby("cluster")[SHARES].mean();centers["provinces"]=profiles.groupby("cluster").size()
    write_table(scores,"cluster_scores");write_table(profiles.reset_index(),"province_profiles")
    write_table(centers.reset_index(),"cluster_centroids")
    return profiles,scores,centers

def nuisance_matrix(panel,trends=False):
    province=pd.get_dummies(panel.province,drop_first=True,dtype=float).to_numpy()
    year=pd.get_dummies(panel.year,drop_first=True,dtype=float).to_numpy()
    matrix=np.column_stack([np.ones(len(panel)),province,year])
    if trends:matrix=np.column_stack([matrix,province*(panel.year.to_numpy()-panel.year.mean())[:,None]])
    return matrix

def residualize(values,nuisance):
    values=np.asarray(values,float)
    return values-nuisance@np.linalg.lstsq(nuisance,values,rcond=None)[0]

def bh_adjust(pvalues):
    p=np.asarray(pvalues);order=np.argsort(p)
    q=np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]
    out=np.empty_like(p);out[order]=np.minimum(q,1);return out

def panel_associations(panel,trends=False):
    nuisance=nuisance_matrix(panel,trends);x=residualize(panel[WEATHER_FEATURES],nuisance)
    y=residualize(panel[SHARES],nuisance)
    if np.linalg.matrix_rank(x)!=3:raise ValueError("Weather coefficients are not identified")
    inv=np.linalg.inv(x.T@x);beta=inv@x.T@y;errors=y-x@beta
    clusters=panel.province.to_numpy();g=len(np.unique(clusters));n=len(panel)
    rank=np.linalg.matrix_rank(np.column_stack([nuisance,x]));correction=g/(g-1)*(n-1)/(n-rank)
    critical=t.ppf(.975,g-1);rows=[]
    for j,group in enumerate(GROUPS):
        meat=np.zeros((3,3))
        for province in np.unique(clusters):
            mask=clusters==province;score=x[mask].T@errors[mask,j];meat+=np.outer(score,score)
        se=np.sqrt(np.maximum(np.diag(correction*inv@meat@inv),0))
        for i,feature in enumerate(WEATHER_FEATURES):
            rows.append(dict(group=group,feature=feature,beta=beta[i,j],se=se[i],
                             ci_low=beta[i,j]-critical*se[i],ci_high=beta[i,j]+critical*se[i],
                             p=2*t.sf(abs(beta[i,j]/se[i]),g-1),n=n,province_clusters=g))
    out=pd.DataFrame(rows);out["q_bh"]=bh_adjust(out.p);return out

def weather_contrasts(panel,bootstrap=2000):
    adjusted=residualize(panel[SHARES],nuisance_matrix(panel));rng=np.random.default_rng(42);rows=[]
    for flag,label in [("warm_year","Warmer summers"),("dry_year","Drier years"),("wet_year","Wetter years")]:
        values=[]
        for province,idx in panel.groupby("province").groups.items():
            idx=np.asarray(list(idx));mask=panel.loc[idx,flag].to_numpy(bool)
            if mask.any() and (~mask).any():values.append(adjusted[idx][mask].mean(0)-adjusted[idx][~mask].mean(0))
        values=np.array(values);draws=values[rng.integers(0,len(values),size=(bootstrap,len(values)))].mean(1)
        low,high=np.quantile(draws,[.025,.975],axis=0)
        for j,group in enumerate(GROUPS):
            rows.append(dict(comparison=label,group=group,difference_pp=values[:,j].mean(),ci_low=low[j],
                             ci_high=high[j],provinces=len(values),selected_rows=int(panel[flag].sum())))
    return write_table(pd.DataFrame(rows),"weather_contrasts")

def sensitivity(panel,main):
    nofruit=panel.copy();masses=np.column_stack([panel.grain_mass,panel.meat_mass,panel.vegetables_kg,panel.egg_dairy_mass,panel.aquatic_mass])
    nofruit[SHARES]=masses/masses.sum(1)[:,None]*100
    variants={"Main model":main,"Province trends":panel_associations(panel,trends=True),
              "Vegetables only":panel_associations(nofruit),
              "2019-2023":panel_associations(panel[panel.year>=2019].copy().reset_index(drop=True))}
    rows=[]
    for name,result in variants.items():
        part=result[result.feature.eq("temp_anomaly_c")].copy();part["specification"]=name;rows.append(part)
    return write_table(pd.concat(rows,ignore_index=True),"sensitivity")

def prediction_features(panel,reference):
    out=panel[["province","year","summer_temp_c","precip_mm"]].copy()
    out["rain_relative"]=out.precip_mm/out.province.map(reference.groupby("province").precip_mm.mean())-1
    out["rain_absolute"]=out.rain_relative.abs();return out

def ridge_model(weather,alpha):
    numeric=["year"]+(["summer_temp_c","rain_relative","rain_absolute"] if weather else [])
    transform=ColumnTransformer([("province",OneHotEncoder(handle_unknown="error",sparse_output=False),["province"]),
                                 ("numeric",StandardScaler(),numeric)])
    return Pipeline([("transform",transform),("ridge",Ridge(alpha=alpha))])

def normalize_predictions(values):
    values=np.clip(values,0,None)
    if np.any(values.sum(1)<=0):raise ValueError("Invalid predicted composition")
    return values/values.sum(1)[:,None]*100

def evaluate_predictions(panel):
    train=panel[panel.year<=2020];validation=panel[panel.year.eq(2021)]
    choices={};tuning=[]
    for weather,name in [(False,"Province + trend"),(True,"Province + trend + weather")]:
        for alpha in [.01,.1,1,10,100]:
            model=ridge_model(weather,alpha);model.fit(prediction_features(train,train),train[SHARES])
            pred=normalize_predictions(model.predict(prediction_features(validation,train)))
            tuning.append(dict(model=name,alpha=alpha,validation_mae_pp=np.abs(pred-validation[SHARES].to_numpy()).mean()))
        choices[name]=min((r for r in tuning if r["model"]==name),key=lambda r:r["validation_mae_pp"])["alpha"]
    rows=[]
    for year in (2022,2023):
        train=panel[panel.year<year];test=panel[panel.year.eq(year)]
        candidates={"Previous year":panel[panel.year.eq(year-1)].set_index("province").loc[test.province,SHARES].to_numpy()}
        for weather,name in [(False,"Province + trend"),(True,"Province + trend + weather")]:
            model=ridge_model(weather,choices[name]);model.fit(prediction_features(train,train),train[SHARES])
            candidates[name]=normalize_predictions(model.predict(prediction_features(test,train)))
        for name,pred in candidates.items():
            for i,(_,record) in enumerate(test.iterrows()):
                for j,group in enumerate(GROUPS):rows.append(dict(model=name,year=year,province=record.province,group=group,observed=record[SHARES[j]],predicted=pred[i,j]))
    predictions=pd.DataFrame(rows);predictions["absolute_error"]=abs(predictions.predicted-predictions.observed)
    predictions["squared_error"]=(predictions.predicted-predictions.observed)**2
    metrics=predictions.groupby(["model","group"],sort=False).agg(mae_pp=("absolute_error","mean"),mse=("squared_error","mean")).reset_index()
    metrics["rmse_pp"]=np.sqrt(metrics.pop("mse"))
    overall=predictions.groupby("model",sort=False).agg(mae_pp=("absolute_error","mean"),mse=("squared_error","mean")).reset_index()
    overall["rmse_pp"]=np.sqrt(overall.pop("mse"))
    errors=predictions.pivot_table(index=["province","year","group"],columns="model",values="absolute_error")
    improvement=(errors["Province + trend"]-errors["Province + trend + weather"]).groupby("province").mean().to_numpy()
    rng=np.random.default_rng(42);draws=improvement[rng.integers(0,len(improvement),size=(5000,len(improvement)))].mean(1)
    low,high=np.quantile(draws,[.025,.975])
    summary=dict(tuned_alphas=choices,test_years=[2022,2023],test_province_years=62,
                 weather_mae_improvement_pp=float(improvement.mean()),paired_province_bootstrap_ci=[float(low),float(high)],bootstrap_draws=5000)
    for frame,name in [(pd.DataFrame(tuning),"ridge_tuning"),(predictions,"predictions"),(metrics,"prediction_metrics"),(overall,"prediction_overall")]:write_table(frame,name)
    (ROOT/"outputs/prediction_summary.json").write_text(json.dumps(summary,indent=2))
    return metrics,overall,predictions,summary
