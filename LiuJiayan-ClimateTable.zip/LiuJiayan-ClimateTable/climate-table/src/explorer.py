"""Create an offline province and year comparison display."""
import json
from .constants import ROOT, GROUPS, SHARES, COLORS

def create_explorer(panel,profiles):
    payload=json.dumps(dict(rows=panel.to_dict("records"),groups=GROUPS,shares=SHARES,
        colors=COLORS,profiles=profiles.reset_index().to_dict("records"),
        geo=json.loads((ROOT/"data/raw/china_provinces.geojson").read_text())),ensure_ascii=False)
    output=ROOT/"outputs/climate_table_explorer.html"
    output.write_text((ROOT/"src/explorer_template.html").read_text().replace("__DATA__",payload),encoding="utf-8")
    return output
