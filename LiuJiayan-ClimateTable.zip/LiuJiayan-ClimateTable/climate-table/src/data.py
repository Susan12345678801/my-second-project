"""Validate source tables and construct a balanced province-year panel."""
import hashlib
import json
import numpy as np
import pandas as pd
from PIL import Image
from .constants import ROOT, YEARS, PROVINCES, CAPITALS, ADM_CODES, FOOD_COLUMNS, SHARES

def validate_and_prepare():
    sources=json.loads((ROOT/"data/sources.json").read_text())
    sources.append(json.loads((ROOT/"data/map_source.json").read_text()))
    for record in sources:
        path=ROOT/record["local_path"]
        if hashlib.sha256(path.read_bytes()).hexdigest()!=record["sha256"]:
            raise ValueError(f"Raw source checksum failed: {path.name}")
        if path.suffix==".jpg":
            with Image.open(path) as image:image.verify()
    checks=json.loads((ROOT/"data/curated/checksums.json").read_text())
    for name,digest in checks.items():
        if hashlib.sha256((ROOT/"data/curated"/name).read_bytes()).hexdigest()!=digest:
            raise ValueError(f"Curated checksum failed: {name}")
    food=pd.read_csv(ROOT/"data/curated/food.csv");weather=pd.read_csv(ROOT/"data/curated/weather.csv")
    audit=pd.read_csv(ROOT/"data/curated/ocr_audit.csv")
    if audit.needs_review.any():raise ValueError("Unresolved source-image reading")
    for frame,keys,columns in [(food,["year","province"],list(FOOD_COLUMNS)),
            (weather,["year","city"],["temp_jun_c","temp_jul_c","temp_aug_c","annual_temp_c","precip_mm"])]:
        if not set(keys+columns).issubset(frame.columns):raise ValueError("Missing source column")
        if frame.duplicated(keys).any():raise ValueError("Duplicate geographic-year key")
        if not np.isfinite(frame[columns].to_numpy()).all():raise ValueError("Missing or nonfinite numeric value")
    if not food[list(FOOD_COLUMNS)].ge(0).all().all():raise ValueError("Negative food consumption")
    if not weather.precip_mm.between(0,6000).all():raise ValueError("Annual rainfall outside validation bounds")
    if not weather[["temp_jun_c","temp_jul_c","temp_aug_c"]].apply(lambda s:s.between(-10,40)).all().all():
        raise ValueError("Summer temperature outside validation bounds")
    metadata=pd.DataFrame(dict(province=PROVINCES,city=CAPITALS,adcode=ADM_CODES))
    provincial=food[food.province.ne("National Average")].merge(metadata,on="province",validate="many_to_one")
    panel=provincial.merge(weather,on=["year","city"],validate="one_to_one")
    expected=pd.MultiIndex.from_product([YEARS,PROVINCES],names=["year","province"])
    observed=pd.MultiIndex.from_frame(panel[["year","province"]])
    if len(panel)!=len(expected) or len(expected.difference(observed)):raise ValueError("Incomplete provincial panel")
    panel=panel.sort_values(["province","year"]).reset_index(drop=True)
    panel["grain_mass"]=panel.grain_kg
    panel["meat_mass"]=panel.meat_kg+panel.poultry_kg
    panel["produce_mass"]=panel.vegetables_kg+panel.fruit_kg
    panel["egg_dairy_mass"]=panel.eggs_kg+panel.milk_kg
    panel["aquatic_mass"]=panel.aquatic_kg
    masses=["grain_mass","meat_mass","produce_mass","egg_dairy_mass","aquatic_mass"]
    panel["selected_mass_kg"]=panel[masses].sum(axis=1)
    if not panel.selected_mass_kg.gt(0).all():raise ValueError("Zero food-share denominator")
    panel[SHARES]=panel[masses].div(panel.selected_mass_kg,axis=0).to_numpy()*100
    if not np.allclose(panel[SHARES].sum(axis=1),100):raise ValueError("Food shares do not sum to 100")
    panel["summer_temp_c"]=(30*panel.temp_jun_c+31*panel.temp_jul_c+31*panel.temp_aug_c)/92
    panel["temp_anomaly_c"]=panel.summer_temp_c-panel.groupby("province").summer_temp_c.transform("mean")
    panel["rain_anomaly_pct"]=100*(panel.precip_mm/panel.groupby("province").precip_mm.transform("mean")-1)
    panel["rain_10pct"]=panel.rain_anomaly_pct/10;panel["rain_abs_10pct"]=panel.rain_10pct.abs()
    panel["warm_year"]=panel.summer_temp_c>panel.groupby("province").summer_temp_c.transform(lambda s:s.quantile(.75))
    panel["dry_year"]=panel.precip_mm<panel.groupby("province").precip_mm.transform(lambda s:s.quantile(.25))
    panel["wet_year"]=panel.precip_mm>panel.groupby("province").precip_mm.transform(lambda s:s.quantile(.75))
    panel["fruit_heading"]=np.where(panel.year<=2021,"Dried and fresh fruit","Fresh fruit")
    (ROOT/"data/processed").mkdir(exist_ok=True);panel.to_csv(ROOT/"data/processed/panel.csv",index=False)
    summary=dict(food_rows_with_national=len(food),weather_city_year_rows=len(weather),provinces=31,
                 years=YEARS,joined_rows=len(panel),missing_numeric_cells=0,duplicate_keys=0,imputed_cells=0,
                 source_images=27,weather_proxy="one capital-area observation per province",fruit_heading_change_year=2022)
    (ROOT/"outputs/validation.json").write_text(json.dumps(summary,indent=2))
    return panel,summary
