"""Shared labels and the row order in the original NBS tables."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
YEARS = list(range(2015, 2024))
PROVINCES = ["Beijing", "Tianjin", "Hebei", "Shanxi", "Inner Mongolia", "Liaoning",
 "Jilin", "Heilongjiang", "Shanghai", "Jiangsu", "Zhejiang", "Anhui", "Fujian",
 "Jiangxi", "Shandong", "Henan", "Hubei", "Hunan", "Guangdong", "Guangxi", "Hainan",
 "Chongqing", "Sichuan", "Guizhou", "Yunnan", "Tibet", "Shaanxi", "Gansu", "Qinghai", "Ningxia", "Xinjiang"]
CAPITALS = ["Beijing", "Tianjin", "Shijiazhuang", "Taiyuan", "Hohhot", "Shenyang",
 "Changchun", "Harbin", "Shanghai", "Nanjing", "Hangzhou", "Hefei", "Fuzhou", "Nanchang",
 "Jinan", "Zhengzhou", "Wuhan", "Changsha", "Guangzhou", "Nanning", "Haikou", "Chongqing",
 "Chengdu", "Guiyang", "Kunming", "Lhasa", "Xian", "Lanzhou", "Xining", "Yinchuan", "Urumqi"]
CITIES = ["Beijing", "Tianjin", "Shijiazhuang", "Taiyuan", "Hohhot", "Shenyang", "Dalian",
 "Changchun", "Harbin", "Shanghai", "Nanjing", "Hangzhou", "Hefei", "Fuzhou", "Nanchang",
 "Jinan", "Qingdao", "Zhengzhou", "Wuhan", "Changsha", "Guangzhou", "Nanning", "Guilin",
 "Haikou", "Chongqing", "Chengdu", "Guiyang", "Kunming", "Lhasa", "Xian", "Lanzhou", "Xining", "Yinchuan", "Urumqi"]
ADM_CODES = [110000,120000,130000,140000,150000,210000,220000,230000,310000,320000,
 330000,340000,350000,360000,370000,410000,420000,430000,440000,450000,460000,
 500000,510000,520000,530000,540000,610000,620000,630000,640000,650000]
FOOD_COLUMNS = {"grain_kg":0,"vegetables_kg":4,"meat_kg":5,"poultry_kg":9,
 "aquatic_kg":10,"eggs_kg":11,"milk_kg":12,"fruit_kg":13}
GROUPS = ["Grain", "Meat and poultry", "Vegetables and fruit", "Eggs and dairy", "Aquatic products"]
SHARES = ["grain_share", "meat_share", "produce_share", "egg_dairy_share", "aquatic_share"]
COLORS = ["#d8a448", "#c96763", "#66a381", "#8c85ad", "#5598b6"]
