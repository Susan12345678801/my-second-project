"""Weather and household food composition in China."""
